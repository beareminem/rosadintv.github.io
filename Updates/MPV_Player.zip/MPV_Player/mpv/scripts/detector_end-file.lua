function detector_idle(name, value)
if value == true then
file = io.open("Media_Ended.txt", "w")
file:write(mp.get_property("fullscreen"))
file:close()
end
end
mp.observe_property("end-file", "bool", detector_idle)