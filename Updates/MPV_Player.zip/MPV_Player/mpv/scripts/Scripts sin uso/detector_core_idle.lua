function detector_idle(name, value)
if value == true then
file = io.open("Estado_Repo.txt", "w")
file:write(mp.get_property("playlist-count"))
file:close()
end
end
mp.observe_property("core-idle", "bool", detector_idle)