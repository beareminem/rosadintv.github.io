seconds = 0 
timer = mp.add_periodic_timer(1, function()

function umaka(nothing)
file = assert(io.open("RESUME_MPV_PB.txt", "r"))
local line = file:read()
-- Si el archivo contiene NO como string no se hace nada
if string.sub(line, 1, 2) ~= 'NO' then
mp.set_property_native("pause", false)
end
-- Se recorre linea por linea hasta llegar al valor
for line in file:lines() do
mp.set_property_native("pause", false)
end
file:close()
os.remove("RESUME_MPV_PB.txt")
end

pcall(umaka,0)

end)
