function detector_idle(name, value)
if value == false then
file = io.open("Media_Ended.txt", "w")
file:write(mp.get_property("fullscreen"))
file:close()
end
end
mp.observe_property("seekable", "bool", detector_idle)