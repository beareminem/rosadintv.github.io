function detector_idle(name, value)
if value == false then
mp.set_property("pause", "no")
end
end
mp.observe_property("seeking", "bool", detector_idle)