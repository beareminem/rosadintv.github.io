file = io.open('MPV_LAUNCHED.rtv', 'w')
file:write('ROSADINTV_LOG_FILE')
file:close()